/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import entidades.ControladoraUsuario;
import entidades.*;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Víctor
 */
@WebServlet(name = "SvEditarProducto", urlPatterns = {"/SvEditarProducto"})
public class SvEditarProducto extends HttpServlet {

   
    ControladoraProducto controlProd = new ControladoraProducto();
    
    
    
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }

   
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

         int id_editar =Integer.parseInt(request.getParameter("id_producto"));
         Producto prod = controlProd.traerProducto(id_editar);
        
        HttpSession misession = request.getSession();
        misession.setAttribute("prodEditar", prod);
        
        
        response.sendRedirect("JSPCode/editarProducto.jsp");






    }

    
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher rs;

        
          String nombre_prod = request.getParameter("nombre_producto");
            Double precio_prod =Double.parseDouble(request.getParameter("precio_producto"));
            int stockDisponible_prod =Integer.parseInt( request.getParameter("stockDisponible_producto"));
            int uds_vendidas_prod = Integer.parseInt(request.getParameter("uds_vendidas"));
            String descripcion_prod = request.getParameter("descripcion_producto");
            int id_categoria = Integer.parseInt(request.getParameter("id_categoria"));

            
            
            Producto prod = (Producto) request.getSession().getAttribute("prodEditar");
            
            prod.setNombre_producto(nombre_prod);
            prod.setPrecio_producto(precio_prod);
            prod.setStockDisponible_producto(stockDisponible_prod);
            prod.setDescripcion_producto(descripcion_prod);
            prod.setId_categoria(id_categoria);
           
        
        controlProd.editarProducto(prod);
        
        
        
         rs = request.getRequestDispatcher("/JSPCode/index.jsp");
         rs.forward(request, response);
        
        
        
        
        
        processRequest(request, response);
    }

    
    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
