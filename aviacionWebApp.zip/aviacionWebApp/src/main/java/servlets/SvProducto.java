/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;


import entidades.*;
import entidades.ControladoraUsuario;
import entidades.Producto;
import entidades.Usuario;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author Víctor
 */
@WebServlet(name = "SvProducto", urlPatterns = {"/SvProducto"})
public class SvProducto extends HttpServlet {
    
    
                RequestDispatcher rs;

                
              
    
    ControladoraProducto prodCont = new ControladoraProducto();


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        
        
    }

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
                RequestDispatcher rsget;

                List<Producto> listaProductos = new ArrayList<>();

                listaProductos = prodCont.traerProducto();
        
                HttpSession misession = request.getSession();
                misession.setAttribute("listaProductos", listaProductos);

                rs = request.getRequestDispatcher("/JSPCode/mostrarProducto.jsp");
                   rs.forward(request, response);
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        processRequest(request, response);
    }

  
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
            String nombre_prod = request.getParameter("nombre_producto");
            Double precio_prod =Double.parseDouble(request.getParameter("precio_producto"));
            int stockDisponible_prod =Integer.parseInt( request.getParameter("stockDisponible_producto"));
            String descripcion_prod = request.getParameter("descripcion_producto");
            int id_categoria = Integer.parseInt(request.getParameter("id_categoria"));
           

            
            
            Producto prod = new Producto();
            
            
            prod.setNombre_producto(nombre_prod);
            prod.setPrecio_producto(precio_prod);
            prod.setStockDisponible_producto(stockDisponible_prod);
            prod.setDescripcion_producto(descripcion_prod);
            prod.setId_categoria(id_categoria);
            
            
            prodCont.crearProducto(prod);
            
            
            

            rs = request.getRequestDispatcher("/JSP/index.jsp");
            rs.forward(request, response);
            
        
        
        
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
