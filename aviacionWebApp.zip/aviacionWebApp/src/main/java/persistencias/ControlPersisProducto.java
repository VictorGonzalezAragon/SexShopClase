/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistencias;

import entidades.*;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import persistencias.exceptions.NonexistentEntityException;

/**
 *
 * @author Víctor
 */
public class ControlPersisProducto {
     ProductoJpaController ProdJpa = new ProductoJpaController();
    
    //Operacion create del JPAController, este crea una nueva categoria
    
    public void crearProducto(Producto prod){
        ProdJpa.create(prod);
    }
    
    //Operacion READ    
    public List<Producto> traerProducto(){
        return ProdJpa.findProductoEntities();
        
                
    }

    public void borrarProducto(int id_eliminar) {

        
         try {
             ProdJpa.destroy(id_eliminar);
         } catch (NonexistentEntityException ex) {
             Logger.getLogger(ControlPersisProducto.class.getName()).log(Level.SEVERE, null, ex);
         }
        
    }

    public Producto traerProducto(int id_editar) {

        return ProdJpa.findProducto(id_editar);



    }
    
    
  

    public void editarProducto(Producto prod) {
        
         try {
             ProdJpa.edit(prod);
         } catch (Exception ex) {
             Logger.getLogger(ControlPersisProducto.class.getName()).log(Level.SEVERE, null, ex);
         }





    }
    
    
    
}


