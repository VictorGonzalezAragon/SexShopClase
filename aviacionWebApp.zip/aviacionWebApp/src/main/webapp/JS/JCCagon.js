window.onload = function() {
    document.getElementById('age-verification').style.display = 'flex';
  };


  document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('enter-btn').addEventListener('click', function() {
      document.getElementById('age-verification').style.display = 'none';
    });
  });